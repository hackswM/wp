<?php return array (
  'site_name' => 'OneIndex',
  'password' => 'oneindex',
  'style' => 'material',
  'onedrive_root' => '',
  'cache_type' => 'secache',
  'cache_expire_time' => 3600,
  'cache_refresh_time' => 600,
  'root_path' => '?',
  'show' => 
  array (
    'stream' => 
    array (
      0 => 'txt',
    ),
    'image' => 
    array (
      0 => 'bmp',
      1 => 'jpg',
      2 => 'jpeg',
      3 => 'png',
      4 => 'gif',
    ),
    'video5' => 
    array (
      0 => 'mp4',
      1 => 'webm',
      2 => 'mkv',
    ),
    'video' => 
    array (
    ),
    'video2' => 
    array (
      0 => 'avi',
      1 => 'mpg',
      2 => 'mpeg',
      3 => 'rm',
      4 => 'rmvb',
      5 => 'mov',
      6 => 'wmv',
      7 => 'asf',
      8 => 'ts',
      9 => 'flv',
    ),
    'audio' => 
    array (
      0 => 'ogg',
      1 => 'mp3',
      2 => 'wav',
    ),
    'code' => 
    array (
      0 => 'html',
      1 => 'htm',
      2 => 'php',
      3 => 'css',
      4 => 'go',
      5 => 'java',
      6 => 'js',
      7 => 'json',
      8 => 'txt',
      9 => 'sh',
      10 => 'md',
    ),
    'doc' => 
    array (
      0 => 'csv',
      1 => 'doc',
      2 => 'docx',
      3 => 'odp',
      4 => 'ods',
      5 => 'odt',
      6 => 'pot',
      7 => 'potm',
      8 => 'potx',
      9 => 'pps',
      10 => 'ppsx',
      11 => 'ppsxm',
      12 => 'ppt',
      13 => 'pptm',
      14 => 'pptx',
      15 => 'rtf',
      16 => 'xls',
      17 => 'xlsx',
    ),
  ),
  'images' => 
  array (
    'home' => false,
    'public' => false,
    'exts' => 
    array (
      0 => 'jpg',
      1 => 'png',
      2 => 'gif',
      3 => 'bmp',
    ),
  ),
  'client_secret' => 'pvXIHGY5$%nrnskTL3789}#',
  'client_id' => 'abb592ee-4c82-41f3-b227-692f638483e9',
  'redirect_uri' => 'https://ju.tn/',
  'refresh_token' => 'OAQABAAAAAAC5una0EUFgTIF8ElaxtWjTGn_HUfbP27k68enr2fSFB1kH4a-xwl-2dOgjPWznwlwCWZowsPIlHB9utqZv_xDuhQYkB7LfTE6_S6rSMI_1cVpMRs42fQVYkZMRUQ3XXkvupN7HxUubZ_tbFAVZmlsTluOICdaeZJA9sL3bP1NxYOi_T2EXHElXLHHBH9L4kE-pV7LzzwDTzKQCkzfV7aC1n5ew2buCyApKmQUuTJqXero9c7pDZlwqPO4l0_udLZCIb6me33X4VgEvFoXe6NaDw24w2AuzICZfAXWnTiJOrQC4paVER3GM423tlpIvyPdxzRNvjCus6o0flJCxWvS_MuOerjJqGUQshYZOXRQjnaGxdv-GiH3-xUwb7-wvPT7QZyxCFBz5rrsfARXP90oLpDU8rylvu9Npy2tPec_svvsQMNyZI56T_MWEm7QuTE2nUxj7Fz9HBn07RdWW0sAkL1FcSA7vFZ6hcSSoT1Z5rgW1X-H31oO_IhzyQEqqYhzTxZSYbQCGegqj933IQNF8ZO_8qtaPRxSGQSjrtgAKyT15cr42Eq1GgVEXUioyaVGiWEJdBDTBz-7H6--gMUHog_GDWlVq1StB4ABctFUPO8CFf9MYEw6813gFuXesIhN8LRyonNSbJ1Zs9gLHs_ScrBiT5JWnF2mkEGWQgLzxmH1-MMEups00TuoqM4QCfVD2jGnN1RJLMph4_PdY-aHjyAoLE8pxaasgTudZV3F0MPxoPkLxg3NFO_njj4lNbVxr_iNrA4V4iQzi4iAABHCZYhiI1l5O1Q0ldAOx9ZqQsSAA',
);